Install virtualenv 

# pip3 install virtualenv


Create a virtual environment 

# python -m virtualenv test

Active virtual environment

# .\test\Scripts\activate

Install opencv-python

# pip3 install opencv-python

Install matplotlib

# pip3 install matplotlib

Run python 

# python file_name.py


