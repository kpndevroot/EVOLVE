import cv2

img = cv2.imread('myimg.jpg',1)


print(img)